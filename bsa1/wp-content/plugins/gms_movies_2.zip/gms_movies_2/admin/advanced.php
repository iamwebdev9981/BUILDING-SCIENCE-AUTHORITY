<html>
    <head>
<style>
    .h{

        margin:200px;
    }
</style>

</head>
<body>
    
<h1 class="h">this is advance page</h1>
</body>

</html>


