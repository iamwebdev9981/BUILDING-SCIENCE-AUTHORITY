<?php 

include('header.php');

 ?>

<h1 class="text-danger display-4 mt-4">This is dashboard </h1>


 <?php 

 include('footer.php');

  ?>