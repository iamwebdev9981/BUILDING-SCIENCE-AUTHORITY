this is add tv show page

