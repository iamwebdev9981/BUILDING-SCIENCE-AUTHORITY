<html>
    <head>
<style>
    .h{

        margin:200px;
    }
    .div1{
        margin-top: 30px;
        /* margin-left: 20px; */
    }
    .txt1{
        margin-left: 70px;
        width: 400px;
        height:40px;
    }
    .txt2{
        margin-left: 54px;
        width: 400px;
        height:40px;
    }
    .txt3{
        margin-left: 63px;
        width: 400px;
        height:40px;
    }
    .txt4{
        margin-left: 55px;
        width: 400px;
        height:40px;
    }
    .bttn1{
        padding: 5px 20px 5px 20px;
        


    }
</style>

</head>
<body>
    <div class="div1">
        <h5>Custimize Title</h5>
        <p>Configure the titles that are generated in importers</p>
        <div class="div2">
            <form action="">
                <label for=""><Strong>Movies</Strong></label>
                <input type="text" name="movie" class="txt1"><br><br><br>

                <label for=""><Strong>TVShows</Strong></label>
                <input type="text" name="tvshow" class="txt2"><br><br><br>

                <label for=""><Strong>Sessons</Strong></label>
                <input type="text" name="sesson" class="txt3"><br><br><br>

                <label for=""><Strong>Episodes</Strong></label>
                <input type="text" name="episode" class="txt4"><br><br><br>

                <input type="submit" name="submit" value="Save Changes"class="bttn1">
                <input type="submit" name="submit" class="bttn1">



            </form>

        </div>

    </div>
</body>

</html>


